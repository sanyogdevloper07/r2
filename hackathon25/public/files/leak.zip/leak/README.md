# Leak

- Category: web
- Difficulty: easy
- Author: obet

## Description

Care to learn about cool rocks?

Author: obet
